@echo off
setlocal
title Instalar ONE PIECE BURNING BLOOD Acessivel 1.0
set "BB_SELF=%~f0"
set "BB_OUT=%~dp0"
set "BB_HOST_EXE=%~dp0Instalar_BurningBloodAccess.exe"
set "BB_PS=%TEMP%\BB_INST_%RANDOM%_%RANDOM%.ps1"
echo A preparar o instalador do mod. Aguarde uns segundos.
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
 "$r=Get-Content -Raw -Encoding UTF8 -LiteralPath $env:BB_SELF;$m='###POWERSHELL_PAYLOAD###';$i=$r.LastIndexOf($m);if($i -lt 0){throw 'payload'};[IO.File]::WriteAllText($env:BB_PS,$r.Substring($i+$m.Length),[Text.UTF8Encoding]::new($true))"
if errorlevel 1 (echo Erro ao preparar.& pause & exit /b 1)
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%BB_PS%"
set "EC=%ERRORLEVEL%"
del "%BB_PS%" >nul 2>&1
exit /b %EC%
###POWERSHELL_PAYLOAD###

# ONE PIECE BURNING BLOOD Acessivel 1.0: instalador de reserva.
# Corre o Instalar_BurningBloodAccess.exe dentro do PowerShell, para quando o Windows
# nao deixa abrir o .exe. Antes disso escreve um diagnostico (so leitura) para se saber
# o que bloqueia os .exe: BurningBloodAccess_instalador_diagnostico.log, ao lado deste ficheiro.
$ErrorActionPreference='Continue'
$dir=$env:BB_OUT.TrimEnd('\')
$exe=$env:BB_HOST_EXE
$log=Join-Path $dir 'BurningBloodAccess_instalador_diagnostico.log'
function D([string]$s){
  if($s.Length -gt 1500){$s=$s.Substring(0,1500)+'...'}
  try{Add-Content -LiteralPath $log -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff')+' '+$s) -Encoding UTF8}catch{}
}
function Inner($e){while($e.InnerException){$e=$e.InnerException};$e}

D '---- Instalar_BurningBloodAccess.cmd 1.0'
try{
  $cv=Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -ErrorAction Stop
  D ('WINDOWS '+$cv.ProductName+' '+$cv.DisplayVersion+' build '+$cv.CurrentBuild+'.'+$cv.UBR+' edicao='+$cv.EditionID)
}catch{D ('WINDOWS erro '+$_.Exception.Message)}
$adm=$false
try{$adm=([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)}catch{}
D ('POWERSHELL '+$PSVersionTable.PSVersion+' linguagem='+$ExecutionContext.SessionState.LanguageMode+' 64bits='+[Environment]::Is64BitProcess+' admin='+$adm+' net='+[Environment]::Version)
try{
  $sac=(Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy' -ErrorAction Stop).VerifiedAndReputablePolicyState
  D ('SMART_APP_CONTROL '+$sac+' (0 desligado, 1 ligado, 2 em avaliacao)')
}catch{D 'SMART_APP_CONTROL sem valor'}
try{D ('SMARTSCREEN explorer='+(Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -ErrorAction Stop).SmartScreenEnabled)}catch{D 'SMARTSCREEN explorer sem valor'}
try{D ('SMARTSCREEN politica='+(Get-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -ErrorAction Stop).EnableSmartScreen)}catch{D 'SMARTSCREEN politica sem valor'}
try{D ('CONTROLO_DE_CONTA admin_pede='+(Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -ErrorAction Stop).ConsentPromptBehaviorAdmin)}catch{}

if(Test-Path -LiteralPath $exe){
  $fi=Get-Item -LiteralPath $exe
  $h='';try{$h=(Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash}catch{}
  D ('EXE '+$exe+' tamanho='+$fi.Length+' sha256='+$h)
  try{$z=Get-Content -LiteralPath $exe -Stream Zone.Identifier -ErrorAction Stop;D ('EXE_MARCA_DA_INTERNET '+($z -join ' | '))}catch{D 'EXE_MARCA_DA_INTERNET nenhuma'}
  try{D ('EXE_ASSINATURA '+(Get-AuthenticodeSignature -LiteralPath $exe).Status)}catch{}
}else{D ('EXE_FALTA '+$exe)}
try{$z=Get-Content -LiteralPath $env:BB_SELF -Stream Zone.Identifier -ErrorAction Stop;D ('CMD_MARCA_DA_INTERNET '+($z -join ' | '))}catch{D 'CMD_MARCA_DA_INTERNET nenhuma'}

try{
  $m=Get-MpComputerStatus -ErrorAction Stop
  D ('DEFENDER modo='+$m.AMRunningMode+' antivirus='+$m.AntivirusEnabled+' tempo_real='+$m.RealTimeProtectionEnabled+' versao='+$m.AMProductVersion)
}catch{D ('DEFENDER estado erro '+$_.Exception.Message)}
try{
  $p=Get-MpPreference -ErrorAction Stop
  D ('DEFENDER pastas_controladas='+$p.EnableControlledFolderAccess+' nuvem='+$p.MAPSReporting+' sem_bloqueio_a_primeira_vista='+$p.DisableBlockAtFirstSeen+' pua='+$p.PUAProtection)
}catch{D ('DEFENDER preferencias erro '+$_.Exception.Message)}
try{
  $det=@(Get-MpThreatDetection -ErrorAction Stop | Where-Object {($_.Resources -join ' ') -match 'BurningBlood|Instalar_|lancador'})
  D ('DEFENDER_DETECOES '+$det.Count)
  foreach($d in ($det|Select-Object -First 10)){
    $n='';try{$n=(Get-MpThreat -ThreatID $d.ThreatID -ErrorAction Stop).ThreatName}catch{}
    D ('  '+$d.InitialDetectionTime+' '+$n+' accao_ok='+$d.ActionSuccess+' '+($d.Resources -join ' ; '))
  }
}catch{D ('DEFENDER_DETECOES erro '+$_.Exception.Message)}

$since=(Get-Date).AddDays(-3)
$qs=@(
  @{LogName='Microsoft-Windows-CodeIntegrity/Operational';StartTime=$since},
  @{LogName='Application';ProviderName=@('.NET Runtime','Application Error','Windows Error Reporting');StartTime=$since},
  @{LogName='Microsoft-Windows-Windows Defender/Operational';StartTime=$since},
  @{LogName='Microsoft-Windows-AppLocker/EXE and DLL';StartTime=$since},
  @{LogName='Microsoft-Windows-SmartScreen/Debug';StartTime=$since}
)
foreach($q in $qs){
  try{
    $ev=@(Get-WinEvent -FilterHashtable $q -MaxEvents 500 -ErrorAction Stop | Where-Object {$_.Message -match 'Instalar_BurningBloodAccess|BurningBloodAccess\.exe|lancador'})
    D ('EVENTOS '+$q.LogName+' '+$ev.Count)
    foreach($e in ($ev|Select-Object -First 8)){D ('  '+$e.TimeCreated.ToString('yyyy-MM-dd HH:mm:ss')+' id='+$e.Id+' '+($e.Message -replace '\s+',' '))}
  }catch{D ('EVENTOS '+$q.LogName+' '+$_.Exception.Message)}
}

# o .exe abre sem a Shell? (42 = sim; o SmartScreen so se mete quando se abre pela Shell)
if(Test-Path -LiteralPath $exe){
  try{
    $psi=New-Object Diagnostics.ProcessStartInfo($exe,'--teste')
    $psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.WorkingDirectory=$dir
    $pr=[Diagnostics.Process]::Start($psi)
    if($pr.WaitForExit(20000)){D ('TESTE_EXE terminou com o codigo '+$pr.ExitCode+' (42 = o .exe abre bem)')}
    else{D 'TESTE_EXE nao terminou em 20 s';try{$pr.Kill()}catch{}}
  }catch{
    $ie=Inner $_.Exception
    $nc='';try{$nc=' erro='+$ie.NativeErrorCode}catch{}
    D ('TESTE_EXE bloqueado: '+$ie.Message+$nc+' hresult=0x'+('{0:X8}' -f $ie.HResult))
  }
}

if(!(Test-Path -LiteralPath $exe)){
  D 'FIM sem o .exe'
  Write-Host 'Não encontrei o ficheiro Instalar_BurningBloodAccess.exe ao lado deste .cmd.'
  Write-Host 'Extraia o zip todo para uma pasta e abra o .cmd dentro dessa pasta.'
  Read-Host 'Enter para fechar'
  exit 1
}
Write-Host 'A abrir o instalador.'
try{
  $asm=[Reflection.Assembly]::Load([IO.File]::ReadAllBytes($exe))
  D 'INSTALADOR carregado no PowerShell'
  $r=$asm.EntryPoint.Invoke($null,@(,[string[]]@()))
  D ('INSTALADOR terminou com o codigo '+$r)
  exit [int]$r
}catch{
  $ie=Inner $_.Exception
  D ('ERRO '+$ie.ToString())
  Write-Host ('O instalador falhou: '+$ie.Message)
  Write-Host ('Envie o ficheiro '+$log)
  Read-Host 'Enter para fechar'
  exit 1
}
